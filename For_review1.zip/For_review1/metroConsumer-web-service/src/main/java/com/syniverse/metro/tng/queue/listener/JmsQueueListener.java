package com.syniverse.metro.tng.queue.listener;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.syniverse.metro.dto.model.Tutorial;

@Component
@Transactional
public class JmsQueueListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(JmsQueueListener.class.getName());

    @JmsListener(destination = "jms/myTestQueue")
    public void listenToMessages(Tutorial tutorial){
        logTheCustomMsg(tutorial);
    }

    @JmsListener(destination = "${jms.queue.jndi-name}")
    public void receiveDistributedQueueMsg(Tutorial tutorial){
        logTheCustomMsg(tutorial);
    }

    private void logTheCustomMsg(Tutorial tutorial) {
        String text = "MESSAGE RECEIVED AT: " + LocalDateTime.now() + ". MSG: " + tutorial;
        LOGGER.info(text);
    }
}
