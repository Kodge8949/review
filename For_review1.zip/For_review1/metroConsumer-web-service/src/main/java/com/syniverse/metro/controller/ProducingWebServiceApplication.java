package com.syniverse.metro.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jms.activemq.ActiveMQAutoConfiguration;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication(scanBasePackages={"com.syniverse.metro"}, exclude = ActiveMQAutoConfiguration.class)
@EnableJms
public class ProducingWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducingWebServiceApplication.class, args);
	}
}
