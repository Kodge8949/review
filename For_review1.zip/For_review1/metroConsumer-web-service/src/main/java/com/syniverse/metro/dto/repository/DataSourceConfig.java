package com.syniverse.metro.dto.repository;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

@Configuration
public class DataSourceConfig {

	@Value("${spring.datasource.jndi-name}")
	private String JndiName;

	@Bean(name = "MetroDataSource")
	public DataSource getMetroDataSource() throws Exception {
		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
		return dataSourceLookup.getDataSource(JndiName);
	}
}
