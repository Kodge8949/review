package com.syniverse.metro.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.syniverse.metro.impl.service.createPostRequestServiceImpl;
import com.syniverse.metro.xsd.neustar.xsd.sea.ESROrder;
import com.syniverse.metro.xsd.neustar.xsd.sea.ESROrder.OrderDetails;
import com.syniverse.metro.xsd.neustar.xsd.sea.ResponseDetailsType;

@Endpoint
public class ESROrderEndpoint {

	private static final String NAMESPACE_URI = "http://www.neustar.com/xsd/sea";

	private static final Logger logger = LoggerFactory.getLogger(ESROrderEndpoint.class);

	@Autowired
	createPostRequestServiceImpl createPostRequestServiceImpl;

	/*
	 * private static Source loadXSD() { Source xsd = new
	 * StreamSource(Thread.currentThread().getContextClassLoader()
	 * .getResourceAsStream("/src/main/resources/XSD/AMDOCS_API/ESROrder.xsd"));
	 * return xsd; }
	 */

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "ESROrder")
	@ResponsePayload
	public ESROrder CreatePortRequest(@RequestPayload ESROrder request)
	/* throws JAXBException, SAXException, IOException */ {

		logger.info("this is a info message");
		logger.warn("this is a warn message");
		logger.error("this is a error message");

		/*
		 * JAXBContext jc = JAXBContext.newInstance(ESROrder.class); JAXBSource source =
		 * new JAXBSource(jc, request);
		 * 
		 * SchemaFactory sf =
		 * SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI); Schema schema=
		 * sf.newSchema(loadXSD()); // Schema schema = sf.newSchema();
		 * 
		 * Validator validator = schema.newValidator(); //
		 * validator.setErrorHandler(newMyErrorHandler()); validator.validate(source);
		 */

		ESROrder ESROrder = new ESROrder();

		String ServiceName = request.getOrderDetails().getNodeList().getNodeName().get(0);
		System.out.println(ServiceName);
		if (ServiceName.equals("createPortRequest")) {
			System.out.println("Service  " + ServiceName);
			// Request body

			createPostRequestServiceImpl.createPostRequestMapping(request);

			// Response body
			OrderDetails orderDetails = new OrderDetails();
			ResponseDetailsType ResponseDetailsType = new ResponseDetailsType();
			ResponseDetailsType.setStatus("ack");
			orderDetails.setResponseDetails(ResponseDetailsType);
			ESROrder.setOrderDetails(orderDetails);			

		} else {
			System.out.println("Not a valid Response");
			OrderDetails orderDetails = new OrderDetails();
			ResponseDetailsType ResponseDetailsType = new ResponseDetailsType();
			ResponseDetailsType.setStatus("nack");
			orderDetails.setResponseDetails(ResponseDetailsType);
			ESROrder.setOrderDetails(orderDetails);
		}

		return ESROrder;
	}
}
