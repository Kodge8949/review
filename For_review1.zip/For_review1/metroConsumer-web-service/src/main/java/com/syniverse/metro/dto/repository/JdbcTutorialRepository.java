package com.syniverse.metro.dto.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.syniverse.metro.dto.model.Tutorial;

@Repository
public class JdbcTutorialRepository implements TutorialRepository {

	@Autowired
	@Qualifier("MetroDataSource")
	DataSource dataSource;

	Connection con;

	@Override
	@Transactional()
	public int save(Tutorial tutorial) throws SQLException {

		con = dataSource.getConnection();
		String query = "INSERT INTO tutorials (id, title, description, published) VALUES(?,?,?,?)";
		PreparedStatement myStmt = con.prepareStatement(query);

		myStmt.setInt(1, tutorial.getId());
		myStmt.setString(2, tutorial.getTitle());
		myStmt.setString(3, tutorial.getDescription());
		myStmt.setBoolean(4, true);

		int res = myStmt.executeUpdate();
		con.close();
		return res;

	}

	@Override
	public int update(Tutorial book) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Tutorial findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteById(Long id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Tutorial> findByTitleContaining(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteAll() {
		// TODO Auto-generated method stub
		return 0;
	}

}