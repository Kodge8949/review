package com.syniverse.metro.impl.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.syniverse.metro.dto.model.Tutorial;
import com.syniverse.metro.dto.repository.TutorialRepository;
import com.syniverse.metro.service.createPortRequestService;
import com.syniverse.metro.util.XMLUtil;
import com.syniverse.metro.xsd.neustar.xsd.sea.ESROrder;
import com.syniverse.tnd.xsd.generated.PORTREQUESTType;
import com.syniverse.tnd.xsd.generated.WnpLINEDATAType;

@Component
@Transactional
public class createPostRequestServiceImpl implements createPortRequestService {

	@Autowired
	TutorialRepository tutorialRepository;

	@Autowired
	private JmsTemplate jmsTemplate;

	@Override
	public void createPostRequestMapping(ESROrder request) {
		// TODO Auto-generated method stub

		PORTREQUESTType portrequestType = new PORTREQUESTType();

		System.out.println("request " + request);

		WnpLINEDATAType wnpLINEDATAType = new WnpLINEDATAType();
		wnpLINEDATAType.setLNUM(request.getCustomerDetails().getProductDetails().getLRN());
		ArrayList<WnpLINEDATAType> arrayList = new ArrayList<WnpLINEDATAType>();
		arrayList.add(wnpLINEDATAType);
		portrequestType.setLinedata(arrayList);

		System.out.println("TND request " + portrequestType.getLINEDATA().get(0).getLNUM());

		String TngRequestXml = XMLUtil.toXML(portrequestType);
		System.out.println("Pojo to XML");
		System.out.println(TngRequestXml);

		jmsTemplate.convertAndSend(TngRequestXml);

		// Database
		try {
			Tutorial tutorial = new Tutorial();
			tutorialRepository.save(new Tutorial(007, "praveenkumar", "kodge", false));
			System.out.println("Tutorial was created successfully.");
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
